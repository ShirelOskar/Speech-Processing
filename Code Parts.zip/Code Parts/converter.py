import os
import ffmpeg
#import ffmpy

inputdir = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project'
out = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project'

for filename in os.listdir(inputdir):
    actual_filename = filename[:-4]
    if(filename.endswith(".mp4")):
        print(filename)
        os.system('ffmpeg -i {} -acodec pcm_s16le -ar 44100 -ac 1 {}.wav'.format(filename, actual_filename))
    else:
        continue
print("finish")