from stt_class import STT
from pydub import AudioSegment

from pyannote.audio import Pipeline

pipeline = Pipeline.from_pretrained(
    "pyannote/speaker-diarization-3.1",
    use_auth_token="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") #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

import torch

import torchaudio

AUDIO_FILE = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project\\chunks\\conv_chunk.wav'

waveform, sample_rate = torchaudio.load(AUDIO_FILE)

audio_in_memory = {"waveform": waveform, "sample_rate": sample_rate}

# apply pretrained pipeline
diarization = pipeline('C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project\\chunks\\conv_chunk.wav', min_speakers=2, max_speakers=2)

# print the result
for turn, _, speaker in diarization.itertracks(yield_label=True):
    print(f"start={turn.start:.1f}s stop={turn.end:.1f}s speaker_{speaker}")




#offline_sep = Pipeline.from_pretrained("config31.yaml")
#offline_sep(audio_in_memory, min_speakers=2, max_speakers=2)




#for speech_turn, track, speaker in offline_sep.itertracks(yield_label=True):
 #   print(f"{speech_turn.start:4.1f} {speech_turn.end:4.1f} {speaker}")








 #   sentance_audio = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project\\chunks\\conv_chunk.wav'
 #  st = STT()

#    sentance = st.recognize(st.opensoundfile(sentance_audio)).results[-1].alternatives[0].words

#    print(sentance)

 #   f = open("conv_transcript.txt", "w")

  #  for word_info in sentance:
  #      #print(f"word: '{word_info.word}', speaker_tag: {word_info.speaker_tag}")
  #      f.write("{}: {}".format(word_info.speaker_tag, word_info.word))
        
   # f.close()