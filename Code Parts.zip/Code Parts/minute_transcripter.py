from stt_class import STT
from pydub import AudioSegment


st = STT()

f = open("session_minutes_transcript.txt", "w")

for i in range(1,28):
    print(i)
    f.write("תמלול של קטע {} :".format(i))
    f.write("\n")
    sentance_audio = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project\\seg{}.wav'.format(i)
    try:        
            sentance = st.recognize(st.opensoundfile(sentance_audio)).results[0].alternatives[0].transcript
    except:
            sentance  =''

    print(i)
    if len(sentance)==0:
        f.write("ללא מלל - תקלה - בכל הקטעים יש מלל")
        f.write("\n")
        continue
    f.write("{}".format(sentance))
    f.write("\n")
    
f.close()