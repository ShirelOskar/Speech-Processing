from stt_class import STT
from pydub import AudioSegment

therapist = [337, 335, 330, 280, 273, 286, 292, 293, 294, 295, 317, 271, 259, 260, 261, 262, 263, 255, 246, 247, 248, 249, 244, 230, 231, 228, 215, 216, 221, 222, 223, 224, 206, 209, 190, 84, 91, 72, 74, 77, 78, 79, 80, 81, 68, 61, 57, 54, 51, 55, 56, 14, 23, 24, 111, 113, 158]

patient = [336, 281, 282, 283, 284, 287, 288, 289, 290, 291, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 274, 275, 276, 277, 278, 279, 272, 268, 269, 270, 266, 256, 258, 251, 252, 253, 254, 245, 238, 239, 240, 241, 242, 232, 233, 234, 235, 236, 225, 226, 227, 211, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 112, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 145, 146, 147, 148, 149, 150, 151, 153, 154, 155, 156, 157, 160, 161, 162, 163, 164, 165, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 207, 208, 85, 86, 87, 88, 89, 82, 83, 75, 76, 73, 71, 69, 62, 63, 64, 65, 66, 67, 59, 60, 52, 53, 42, 43, 46, 41, 40, 33, 34, 35, 36, 37, 38, 28, 30, 31, 27, 25, 22, 20, 21, 17, 18, 15, 13, 331, 332, 333]

both = [285, 267, 264, 265, 257, 250, 243, 237, 229, 212, 210, 178, 90, 144, 166, 159, 70, 58, 32, 26, 334, 19, 12]

st = STT()
count = 0.0
f = open("session_transcript_2.txt", "w")

for i in range(0,339):
    sentance_audio = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project\\chunks\\len850st25\\chunk{}.wav'.format(i)
    try:        
            sentance = st.recognize(st.opensoundfile(sentance_audio)).results[0].alternatives[0].transcript
    except:
            sentance  =''
    audio_file = AudioSegment.from_file(sentance_audio)
    duration = audio_file.duration_seconds
    print(i)
    if len(sentance)==0:
        count = count + duration
        continue
    count = float("%.2f" % count)
    minutes = int(int(count)/60)
    seconds = count - (minutes*60)
    seconds = float("%.2f" % seconds)
    if (i in both):
        f.write("מטפל + מטופל [chunk{} , {}:{}]: {}".format(i, minutes, seconds, sentance))
        f.write("\n")
        count = count + duration
        continue
    if (i in patient):
        f.write("מטופל [chunk{} , {}:{}]: {}".format(i, minutes, seconds, sentance))
        f.write("\n")
        count = count + duration
        continue
    if (i in therapist):
        f.write("מטפל [chunk{} , {}:{}]: {}".format(i, minutes, seconds, sentance))
        f.write("\n")
        count = count + duration
        continue
    
f.close()