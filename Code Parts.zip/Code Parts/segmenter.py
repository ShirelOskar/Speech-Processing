import os
from pydub import AudioSegment
from pydub.silence import split_on_silence

inputdir = 'C:\\Users\\matan\\Desktop\\College\\Year C\\Sem A\\Speech Analysis\\Final Project'

for filename in os.listdir(inputdir):
    actual_filename = filename[:-4]
    if(filename.endswith(".wav")):
        print(filename)
        sound = AudioSegment.from_wav(filename)
        audio_chunks = split_on_silence(sound, min_silence_len = 900, silence_thresh = -30, keep_silence = True)
        for i, chunk in enumerate(audio_chunks):
            output_file = "{}\\chunks\\chunk{}.wav".format(inputdir, i)
            print("Exporting file", output_file)
            chunk.export(output_file, format="wav")
    else:
        continue
        
        
